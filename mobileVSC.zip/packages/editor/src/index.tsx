import MonacoEditor, { MonacoEditorRef } from 'react-native-monaco-editor';
export default MonacoEditor;
export { MonacoEditorRef };
