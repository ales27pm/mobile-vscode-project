export const FS_EVENT = 'FS_EVENT';
export const DEBUG_EVENT = 'DEBUG_EVENT';
